package com.example.android.jokelib;

public class Jokes {
    private static String joke = "Everyone for himself, God for us all";

    public static String getJoke() {
        return joke;
    }
}
